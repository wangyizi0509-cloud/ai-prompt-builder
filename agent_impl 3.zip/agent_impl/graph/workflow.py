"""
LangGraph 工作流编排
定义 Agent 之间的调用关系和状态流转

架构说明：
- 主 Agent 是决策中枢，负责协调子 Agent
- 主 Agent 和子 Agent 都可以通过「提问 Skill」向用户提问
- 所有 Agent 提问后会暂停，用户回答后从 resume_point 恢复执行
- wait_user_input 节点负责等待用户输入并路由到正确的 Agent
- 主 Agent 可以使用咨询 Skills 直接回复用户

渐进式加载机制（Tool-based）：
- Agent 可以通过专用工具（如 load_inquiry_skill_instructions）按需加载技能指令
- skill_tools 节点负责执行工具调用
- 工具执行完成后自动返回调用它的 Agent

v2.1 更新：
- 添加 Checkpointer 支持（默认使用 MemorySaver）
- 支持自定义 checkpointer（生产环境可替换为 PostgreSQL/Redis）
"""

from typing import Literal, Optional
from langgraph.graph import StateGraph, END
from langgraph.prebuilt import ToolNode
from langgraph.checkpoint.memory import MemorySaver

from graph.state import AgentState
from graph.nodes.router import router_node
from graph.nodes.main_agent import main_agent_node
from graph.nodes.status_agent import status_agent_node
from graph.nodes.plan_agent import plan_agent_node
from graph.nodes.guide_agent import guide_agent_node
from graph.nodes.finalizer import post_turn_finalize_node
from onboarding.workflow import compile_onboarding_workflow
from skills import (
    load_inquiry_skill_instructions,
    load_consult_answer_skill_instructions,
    load_emotion_support_skill_instructions
)


def route_after_router(state: AgentState) -> Literal["onboarding", "main_agent", "status_agent", "plan_agent", "guide_agent", "end"]:
    """
    路由节点后的条件路由
    
    如果有 current_agent 说明需要恢复之前的 Agent 执行
    支持主 Agent 和所有子 Agent 的恢复
    """
    # 防止无限循环
    iteration = state.get("_iteration_count", 0)
    if iteration > 10:
        print("[WARN] Max iterations reached, forcing end")
        return "end"

    route_to = state.get("route_to", "main_agent")
    if route_to == "end":
        return "end"
    if route_to == "onboarding":
        return "onboarding"
    
    # 检查是否需要恢复之前的 Agent（包括主 Agent）
    current_agent = state.get("current_agent")
    if current_agent and state.get("agent_resume_point"):
        # 直接返回需要恢复的 Agent
        if current_agent == "main_agent":
            return "main_agent"  # 新增：支持主 Agent 恢复
        elif current_agent == "status_agent":
            return "status_agent"
        elif current_agent == "plan_agent":
            return "plan_agent"
        elif current_agent == "guide_agent":
            return "guide_agent"
    
    return "main_agent"


def route_after_onboarding(state: AgentState) -> Literal["router", "end"]:
    """
    Onboarding 子图完成后：
    - 如果 onboarding_completed=False（需要用户回答），本轮结束
    - 如果 onboarding_completed=True，进入 router，再由 router 分发到主 Agent
    """
    if state.get("onboarding_completed", False):
        return "router"
    return "end"


def _has_tool_calls(state: AgentState) -> bool:
    """
    检查最后一条消息是否包含 tool_calls
    
    用于判断 Agent 是否需要调用工具
    """
    messages = state.get("messages", [])
    if not messages:
        return False
    
    last_message = messages[-1]
    # LangChain 的 AIMessage 有 tool_calls 属性
    if hasattr(last_message, "tool_calls") and last_message.tool_calls:
        return True
    # 兼容字典格式
    if isinstance(last_message, dict) and last_message.get("tool_calls"):
        return True
    
    return False


def route_after_main_agent(state: AgentState) -> Literal["skill_tools", "status_agent", "plan_agent", "guide_agent", "end"]:
    """
    主 Agent 后的条件路由
    根据 next_action 决定下一步
    
    优先级：
    1. 如果有 tool_calls，先执行工具
    2. 根据 next_action 路由
    """
    # 优先检查是否有工具调用
    if _has_tool_calls(state):
        return "skill_tools"
    
    next_action = state.get("next_action", "end_turn")
    
    if next_action == "call_status":
        return "status_agent"
    elif next_action == "call_plan":
        return "plan_agent"
    elif next_action == "call_guide":
        return "guide_agent"
    elif next_action == "ask_user":
        # 主 Agent 需要提问，但使用了 interrupt 机制，
        # 如果代码走到这里，说明 interrupt 已经完成或被绕过，
        # 且 Agent 显式返回了 ask_user（可能是为了结束这一轮 invoke）
        return "end"
    else:
        # end_turn 结束本轮
        return "end"


def route_after_sub_agent(state: AgentState) -> Literal["skill_tools", "main_agent", "end"]:
    """
    子 Agent（status/plan/guide）后的统一路由
    
    优先级：
    1. 如果有 tool_calls，先执行工具
    2. 如果子 Agent 设置了 current_agent（需要提问），则等待用户输入
    3. 如果子 Agent 完成了任务，则返回主 Agent 再决策
    """
    # 优先检查是否有工具调用
    if _has_tool_calls(state):
        return "skill_tools"
    
    # 如果有待回答的问题，使用 interrupt 机制，这里直接结束
    if state.get("current_agent") and state.get("agent_resume_point"):
        return "end"
    
    # 任务完成，返回主 Agent 进行再决策
    return "main_agent"


def route_after_skill_tools(state: AgentState) -> Literal["main_agent", "status_agent", "plan_agent", "guide_agent"]:
    """
    skill_tools 节点执行完成后的路由
    
    返回到调用工具的 Agent，让它继续处理
    """
    current_agent = state.get("current_agent", "main_agent")
    
    if current_agent == "status_agent":
        return "status_agent"
    elif current_agent == "plan_agent":
        return "plan_agent"
    elif current_agent == "guide_agent":
        return "guide_agent"
    else:
        return "main_agent"


# 创建 Skill 工具节点（全局复用）
_skill_tools_node = ToolNode([
    load_inquiry_skill_instructions,
    load_consult_answer_skill_instructions,
    load_emotion_support_skill_instructions
])


def skill_tools_node(state: AgentState) -> dict:
    """
    Skill 工具执行节点
    仅执行工具，不修改额外状态
    """
    return _skill_tools_node.invoke(state)


def create_workflow() -> StateGraph:
    """
    创建 LangGraph 工作流
    
    工作流结构（Tool-based 渐进式加载版）：
    
    [用户输入] 
         │
         ▼
    [Router] ─── 风控/闲聊 ───→ [END]
         │
         ├── 有 current_agent ───→ [恢复对应 Agent]（包括主 Agent）
         │
         │ 无 current_agent
         ▼
    [Main Agent] ─── end_turn ───→ [END]
         │
         ├── tool_calls ──→ [Skill Tools] ──→ [Main Agent] (循环)
         │
         ├── ask_user ────→ [Wait User Input] → [END]
         │                  (下轮从 Router 恢复到 Main Agent)
         │
         ├── call_status ──→ [Status Agent] ──┐
         ├── call_plan ────→ [Plan Agent] ───┼──→ [tool_calls?]
         └── call_guide ───→ [Guide Agent] ──┘        │
                                                      ├── 是 → [Skill Tools] → [回到调用者]
                                                      ├── 需要提问 → [Wait User Input] → [END]
                                                      └── 完成 → [Main Agent] (再决策)
    
    Returns:
        编译后的 LangGraph 工作流
    """
    # 创建状态图
    workflow = StateGraph(AgentState)
    
    # 添加节点
    workflow.add_node("router", router_node)
    workflow.add_node("onboarding", compile_onboarding_workflow())
    workflow.add_node("main_agent", main_agent_node)
    workflow.add_node("status_agent", status_agent_node)
    workflow.add_node("plan_agent", plan_agent_node)
    workflow.add_node("guide_agent", guide_agent_node)
    workflow.add_node("post_turn_finalize", post_turn_finalize_node)
    # workflow.add_node("wait_user_input", wait_user_input_node) # Removed in Phase 3
    workflow.add_node("skill_tools", skill_tools_node)  # 新增：Skill 工具节点
    
    # 设置入口点
    workflow.set_entry_point("router")

    # Onboarding 完成后进入 Router
    workflow.add_conditional_edges(
        "onboarding",
        route_after_onboarding,
        {
            "router": "router",
            "end": "post_turn_finalize",
        }
    )

    # Router 后的路由：可能先到 Onboarding，也可能直接到主 Agent，或恢复 Agent
    workflow.add_conditional_edges(
        "router",
        route_after_router,
        {
            "onboarding": "onboarding",
            "main_agent": "main_agent",
            "status_agent": "status_agent",
            "plan_agent": "plan_agent",
            "guide_agent": "guide_agent",
            "end": "post_turn_finalize",
        }
    )
    
    # 主 Agent 后的路由（新增 skill_tools 支持）
    workflow.add_conditional_edges(
        "main_agent",
        route_after_main_agent,
        {
            "skill_tools": "skill_tools",  # 新增：工具调用
            "status_agent": "status_agent",
            "plan_agent": "plan_agent",
            "guide_agent": "guide_agent",
            # "wait_user_input": "wait_user_input", # Removed in Phase 3
            "end": "post_turn_finalize",
        }
    )
    
    # 子 Agent 后的统一路由：工具调用 / 等待用户输入 / 回主 Agent
    workflow.add_conditional_edges(
        "status_agent",
        route_after_sub_agent,
        {
            "skill_tools": "skill_tools",  # 新增：工具调用
            "main_agent": "main_agent",
            "end": "post_turn_finalize",
            # "wait_user_input": "wait_user_input", # Removed in Phase 3
        }
    )
    
    workflow.add_conditional_edges(
        "plan_agent",
        route_after_sub_agent,
        {
            "skill_tools": "skill_tools",  # 新增：工具调用
            "main_agent": "main_agent",
            "end": "post_turn_finalize",
            # "wait_user_input": "wait_user_input", # Removed in Phase 3
        }
    )
    
    workflow.add_conditional_edges(
        "guide_agent",
        route_after_sub_agent,
        {
            "skill_tools": "skill_tools",  # 新增：工具调用
            "main_agent": "main_agent",
            "end": "post_turn_finalize",
            # "wait_user_input": "wait_user_input", # Removed in Phase 3
        }
    )
    
    # skill_tools 执行完成后，返回到调用它的 Agent
    workflow.add_conditional_edges(
        "skill_tools",
        route_after_skill_tools,
        {
            "main_agent": "main_agent",
            "status_agent": "status_agent",
            "plan_agent": "plan_agent",
            "guide_agent": "guide_agent",
        }
    )

    # Finalizer 只做“落库 + 入队”，之后结束本轮
    workflow.add_edge("post_turn_finalize", END)
    
    # wait_user_input 直接结束本轮 (Removed in Phase 3)
    # workflow.add_edge("wait_user_input", END)
    
    return workflow


def compile_workflow(checkpointer=None):
    """
    编译工作流
    
    Args:
        checkpointer: 可选的 checkpointer 实例
                     - None: 使用默认的 MemorySaver（适合开发/测试）
                     - 自定义实例: 可传入 PostgresSaver/RedisSaver 等（适合生产环境）
    
    Returns:
        可执行的工作流实例
    """
    workflow = create_workflow()
    
    # 如果未提供 checkpointer，使用 MemorySaver 作为默认值
    if checkpointer is None:
        checkpointer = MemorySaver()
    
    return workflow.compile(checkpointer=checkpointer)


# 创建全局工作流实例（单例模式）
_compiled_workflow = None
_current_checkpointer = None


def get_workflow(checkpointer=None):
    """
    获取编译后的工作流（单例模式）
    
    Args:
        checkpointer: 可选的 checkpointer 实例
                     - 如果提供新的 checkpointer，会重新编译工作流
                     - 如果为 None 且之前已编译，返回缓存的实例
    
    Returns:
        编译后的工作流实例
    """
    global _compiled_workflow, _current_checkpointer
    
    # 如果提供了新的 checkpointer 或首次调用，重新编译
    if _compiled_workflow is None or (checkpointer is not None and checkpointer is not _current_checkpointer):
        _current_checkpointer = checkpointer
        _compiled_workflow = compile_workflow(checkpointer)
    
    return _compiled_workflow


def reset_workflow():
    """
    重置工作流实例
    
    用于测试或需要重新初始化工作流的场景
    """
    global _compiled_workflow, _current_checkpointer
    _compiled_workflow = None
    _current_checkpointer = None

