import os
import sys
import uvicorn
import json
import time
from pathlib import Path
from fastapi import FastAPI, HTTPException, UploadFile, File, Form, Query, BackgroundTasks
from fastapi.responses import StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from typing import Literal, Optional

# Add path to ensure imports work
current_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, current_dir)

from graph.workflow import get_workflow
from graph.state import create_initial_state
from graph.archive_manager import (
    archive_guide_on_completion,  # legacy (kept for compatibility)
    refine_on_onboarding_complete,
    compress_layer3,
    compress_task_reasoning,
    archive_guide_to_layer2,
    archive_status_to_layer2,
    archive_plan_to_layer2,
)
from utils.image_processor import get_image_processor, ScreenshotType
from datetime import datetime

app = FastAPI(title="Crushe AI Agent")

class ChatRequest(BaseModel):
    message: str
    session_id: str

class CompleteGuideRequest(BaseModel):
    guide_id: str
    execution_status: Literal["perfect", "good", "normal", "failed", "skipped"]
    feedback: Optional[str] = ""
    session_id: str

class StreamChatRequest(BaseModel):
    message: str
    session_id: str
    stream_mode: Optional[Literal["values", "updates", "messages", "debug"]] = "updates"

# 注意：主要状态存储依赖 LangGraph Checkpointer
# sessions 仅用于极简缓存/兼容（非持久化）
sessions = {}
LOG_PATH = Path("/Users/ant/Desktop/Crushe/模型策略/.cursor/debug.log")


#region agent log
def _append_debug_log(run_id: str, hypothesis_id: str, location: str, message: str, data: dict):
    payload = {
        "sessionId": "debug-session",
        "runId": run_id,
        "hypothesisId": hypothesis_id,
        "location": location,
        "message": message,
        "data": data,
        "timestamp": int(time.time() * 1000),
    }
    try:
        with LOG_PATH.open("a", encoding="utf-8") as f:
            f.write(json.dumps(payload, ensure_ascii=False) + "\n")
    except Exception:
        pass
#endregion


# ============================================================
# 异步维护任务：提纯/归档（best-effort，不阻塞用户回复）
# ============================================================

def _safe_update_state(workflow, config: dict, updates: dict) -> None:
    if updates and hasattr(workflow, "update_state"):
        workflow.update_state(config, updates)


def _run_maintenance_tasks(session_id: str) -> None:
    """
    后台消费 maintenance_queue。
    - 读取最新 state（避免拿到过期的 final_state）
    - best-effort 执行：失败记录在 queue item 里，下一轮可重试
    """
    workflow = get_workflow()
    config = {"configurable": {"thread_id": session_id}}

    checkpoint = workflow.get_state(config)
    state = checkpoint.values if checkpoint and checkpoint.values else None
    if not state:
        return

    queue = state.get("maintenance_queue") or []
    if not isinstance(queue, list) or not queue:
        return

    flags = state.get("maintenance_flags") if isinstance(state.get("maintenance_flags"), dict) else {}

    updated_queue = []
    any_changes = False

    for item in queue:
        if not isinstance(item, dict):
            continue

        task_type = item.get("type")
        task_key = item.get("task_key")
        status = item.get("status", "queued")

        # 已完成/跳过的不再执行
        if status in ("done", "skipped"):
            updated_queue.append(item)
            continue

        # 标记 running
        running_item = dict(item)
        running_item["status"] = "running"
        running_item["attempts"] = int(running_item.get("attempts", 0) or 0) + 1
        running_item["last_error"] = None
        updated_queue.append(running_item)
        any_changes = True
        _safe_update_state(workflow, config, {"maintenance_queue": updated_queue})

        try:
            #region agent log
            _append_debug_log(
                run_id="maintenance",
                hypothesis_id="M1",
                location="server.py:_run_maintenance_tasks:start",
                message="Maintenance task started",
                data={
                    "session_id": session_id,
                    "type": task_type,
                    "task_key": task_key,
                    "attempts": running_item.get("attempts"),
                },
            )
            #endregion

            updates = {}

            if task_type == "onboarding_refine":
                updates = refine_on_onboarding_complete(state)
                # 标记 done
                flags = dict(flags)
                flags["onboarding_refine_done"] = True
                flags["onboarding_refine_queued"] = False
                updates["maintenance_flags"] = flags

            elif task_type == "layer3_compress":
                updates = compress_layer3(state)

            elif task_type == "task_reasoning_compress":
                updates = compress_task_reasoning(state)

            elif task_type == "archive_guide":
                payload = item.get("payload") or {}
                guide_id = payload.get("guide_id")
                if guide_id:
                    guide_obj = None
                    for g in state.get("action_guides", []) or []:
                        if isinstance(g, dict) and g.get("id") == guide_id:
                            guide_obj = g
                            break
                    if guide_obj:
                        updates = archive_guide_to_layer2(guide_obj, state)
                        # 记录已归档 guide_id，避免重复
                        flags = dict(flags)
                        archived = flags.get("archived_guide_ids") or []
                        if not isinstance(archived, list):
                            archived = []
                        if guide_id not in archived:
                            archived.append(guide_id)
                        flags["archived_guide_ids"] = archived
                        updates["maintenance_flags"] = flags
                    else:
                        # 找不到 guide，则跳过
                        updates = {}

            elif task_type == "archive_status":
                payload = item.get("payload") or {}
                report_uid = payload.get("report_uid")
                if report_uid:
                    old_report = None
                    layer2_memory = state.get("layer2_memory") or {}
                    reports = layer2_memory.get("all_status_reports", []) if isinstance(layer2_memory, dict) else []
                    for r in reports or []:
                        if isinstance(r, dict) and r.get("id") == report_uid:
                            old_report = r
                            break
                    if old_report:
                        updates = archive_status_to_layer2(old_report, state)
                        flags = dict(flags)
                        archived = flags.get("archived_status_ids") or []
                        if not isinstance(archived, list):
                            archived = []
                        if report_uid not in archived:
                            archived.append(report_uid)
                        flags["archived_status_ids"] = archived
                        updates["maintenance_flags"] = flags

            elif task_type == "archive_plan":
                payload = item.get("payload") or {}
                plan_uid = payload.get("plan_uid")
                if plan_uid:
                    old_plan = None
                    layer2_memory = state.get("layer2_memory") or {}
                    plans = layer2_memory.get("all_action_plans", []) if isinstance(layer2_memory, dict) else []
                    for p in plans or []:
                        if isinstance(p, dict) and p.get("id") == plan_uid:
                            old_plan = p
                            break
                    if old_plan:
                        updates = archive_plan_to_layer2(old_plan, state)
                        flags = dict(flags)
                        archived = flags.get("archived_plan_ids") or []
                        if not isinstance(archived, list):
                            archived = []
                        if plan_uid not in archived:
                            archived.append(plan_uid)
                        flags["archived_plan_ids"] = archived
                        updates["maintenance_flags"] = flags

            else:
                # 未识别任务类型：跳过（保留给后续版本）
                done_item = dict(running_item)
                done_item["status"] = "skipped"
                done_item["last_error"] = f"unknown_task_type:{task_type}"
                updated_queue[-1] = done_item
                _safe_update_state(workflow, config, {"maintenance_queue": updated_queue})
                continue

            # 写回 memory 变更（如果有）
            if updates:
                state.update(updates)
                _safe_update_state(workflow, config, updates)

            # 标记 done
            done_item = dict(updated_queue[-1])
            done_item["status"] = "done"
            done_item["finished_at"] = datetime.now().isoformat()
            updated_queue[-1] = done_item
            _safe_update_state(workflow, config, {"maintenance_queue": updated_queue})

            #region agent log
            _append_debug_log(
                run_id="maintenance",
                hypothesis_id="M2",
                location="server.py:_run_maintenance_tasks:done",
                message="Maintenance task done",
                data={
                    "session_id": session_id,
                    "type": task_type,
                    "task_key": task_key,
                    "updated_keys": list(updates.keys()) if isinstance(updates, dict) else [],
                },
            )
            #endregion

        except Exception as e:
            fail_item = dict(updated_queue[-1])
            fail_item["status"] = "failed"
            fail_item["last_error"] = str(e)
            updated_queue[-1] = fail_item
            _safe_update_state(workflow, config, {"maintenance_queue": updated_queue})

            #region agent log
            _append_debug_log(
                run_id="maintenance",
                hypothesis_id="M3",
                location="server.py:_run_maintenance_tasks:failed",
                message="Maintenance task failed",
                data={
                    "session_id": session_id,
                    "type": task_type,
                    "task_key": task_key,
                    "error": str(e),
                },
            )
            #endregion

    # 最终写回（以防中途未写）
    if any_changes:
        _safe_update_state(workflow, config, {"maintenance_queue": updated_queue})


# ============ 图片上传接口 ============

@app.post("/api/upload-screenshot")
async def upload_screenshot(
    file: UploadFile = File(...),
    screenshot_type: ScreenshotType = Form(...),
    session_id: str = Form(...),
    context: Optional[str] = Form(None)
):
    """
    上传截图并转换为文本
    
    Args:
        file: 图片文件
        screenshot_type: 截图类型 (private_chat_screenshot / group_chat_screenshot / moments_screenshot / other_social_media_screenshot)
        session_id: 会话 ID
        context: 用户补充说明（可选）
    
    Returns:
        {
            "success": bool,
            "text": str,  # 提取的文本，可直接作为用户输入
            "screenshot_type": str,
            "error": str | None
        }
    """
    print(f"📷 收到截图上传: type={screenshot_type}, session={session_id}")
    
    # 读取图片
    try:
        image_bytes = await file.read()
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"读取图片失败: {str(e)}")
    
    # 调用多模态模型处理
    processor = get_image_processor()
    result = await processor.process_image(
        image_bytes=image_bytes,
        screenshot_type=screenshot_type,
        additional_context=context
    )
    
    print(f"📷 处理结果: success={result['success']}")
    
    return result

@app.post("/api/chat")
async def chat(request: ChatRequest, background_tasks: BackgroundTasks):
    print(f"Received message from session {request.session_id}: {request.message}")
    
    workflow = get_workflow()
    config = {"configurable": {"thread_id": request.session_id}}
    
    # 从 Checkpointer 获取历史状态（若不存在则初始化）
    checkpoint = workflow.get_state(config)
    base_state = checkpoint.values if checkpoint and checkpoint.values else None
    if base_state is None:
        print("Creating new session (checkpointer empty)")
        state = create_initial_state(request.message)
    else:
        state = base_state
        # 仅更新当前用户消息，消息追加交由 router/add_messages 处理
        state["user_message"] = request.message
        # 清理上一轮残留
        state["debug_log"] = []
        state["inquiry_card"] = None
        state["pending_questions"] = []
        state["pending_responses"] = []
        state["last_response_for_continuity"] = None

    # Invoke workflow
    try:
        print("Invoking workflow...")
        #region agent log
        _append_debug_log(
            run_id="pre-fix",
            hypothesis_id="H3",
            location="server.py:chat:entry",
            message="Enter chat endpoint",
            data={
                "session_id": request.session_id,
                "message_preview": request.message[:100],
                "use_stream": False,
            },
        )
        #endregion
        final_state = workflow.invoke(state, config)

        # 异步维护任务（提纯/归档/压缩）：不阻塞用户回复
        background_tasks.add_task(_run_maintenance_tasks, request.session_id)
        
        # 仅用于兼容/调试的轻量缓存
        sessions[request.session_id] = final_state
        
        # 处理 pending_responses
        pending_responses = final_state.get("pending_responses", [])
        
        # 向后兼容：合并所有回复为单个 response 字符串
        if pending_responses:
            combined_response = "\n\n".join([r["content"] for r in pending_responses if r.get("content")])
        else:
            combined_response = ""
        
        #region agent log
        _append_debug_log(
            run_id="pre-fix",
            hypothesis_id="H1",
            location="server.py:chat:final_state",
            message="Final state before response",
            data={
                "has_pending_responses": bool(pending_responses),
                "pending_resp_count": len(pending_responses),
                "pending_first_has_card": bool(pending_responses[0].get("inquiry_card")) if pending_responses else False,
                "state_has_inquiry_card": bool(final_state.get("inquiry_card")),
                "onboarding_completed": final_state.get("onboarding_completed"),
                "next_action": final_state.get("next_action"),
                "route_to": state.get("route_to"),
            },
        )
        #endregion
        
        # Return response and state (including debug_log)
        return {
            "response": combined_response,
            "pending_responses": pending_responses,  # 新增：分条回复列表
            "state": final_state
        }
    except Exception as e:
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))


# ============ Streaming 接口 ============

@app.post("/api/chat/stream")
async def chat_stream(request: StreamChatRequest, background_tasks: BackgroundTasks):
    """
    流式聊天接口 - 实时查看 Agent 执行过程
    
    支持多种流模式：
    - values: 每个步骤后的完整状态
    - updates: 每个步骤的状态更新（推荐）
    - messages: LLM tokens 和元数据
    - debug: 最详细的调试信息
    
    使用 Server-Sent Events (SSE) 格式返回数据
    """
    print(f"[Stream] Received message from session {request.session_id}: {request.message}")
    print(f"[Stream] Stream mode: {request.stream_mode}")
    
    workflow = get_workflow()
    config = {"configurable": {"thread_id": request.session_id}}
    
    checkpoint = workflow.get_state(config)
    base_state = checkpoint.values if checkpoint and checkpoint.values else None
    if base_state is None:
        print("[Stream] Creating new session (checkpointer empty)")
        state = create_initial_state(request.message)
    else:
        print("[Stream] Restoring existing session (checkpointer)")
        state = base_state
        state["user_message"] = request.message
        state["debug_log"] = []
        state["inquiry_card"] = None
        state["pending_questions"] = []
        state["pending_responses"] = []
        state["last_response_for_continuity"] = None
    
    async def generate_stream():
        """生成流式响应"""
        final_state = None
        try:
            # 使用 astream 进行异步流式调用
            # 在流式过程中累积最终状态
            async for chunk in workflow.astream(state, config=config, stream_mode=request.stream_mode):
                # 统一前端期望的事件格式
                event_name = request.stream_mode or "values"
                chunk_data = {
                    "event": event_name,  # 前端据此判断类型：values / updates / messages / debug
                    "data": chunk,
                    "stream_mode": request.stream_mode
                }
                
                #region agent log
                _append_debug_log(
                    run_id="pre-fix",
                    hypothesis_id="H3",
                    location="server.py:chat_stream:chunk",
                    message="Stream chunk",
                    data={
                        "event": event_name,
                        "has_inquiry_card": bool(chunk.get("inquiry_card")) if isinstance(chunk, dict) else False,
                        "has_pending_responses": bool(chunk.get("pending_responses")) if isinstance(chunk, dict) else False,
                        "pending_resp_count": len(chunk.get("pending_responses", []) or []) if isinstance(chunk, dict) else None,
                        "nodes": list(chunk.keys()) if isinstance(chunk, dict) else None,
                    },
                )
                #endregion

                # SSE 格式：data: {json}\n\n
                yield f"data: {json.dumps(chunk_data, ensure_ascii=False, default=str)}\n\n"
                
                # 累积状态（用于获取最终状态）
                if request.stream_mode == "values":
                    # values 模式：chunk 就是完整状态
                    final_state = chunk
                elif request.stream_mode == "updates":
                    # updates 模式：需要合并更新到状态
                    for node_name, node_update in chunk.items():
                        state.update(node_update)
                        #region agent log
                        _append_debug_log(
                            run_id="pre-fix",
                            hypothesis_id="H2",
                            location="server.py:chat_stream:updates_merge",
                            message="Merging stream update",
                            data={
                                "node": node_name,
                                "has_inquiry_card": bool(node_update.get("inquiry_card")),
                                "pending_resp_count": len(node_update.get("pending_responses", []) or []),
                                "onboarding_completed": node_update.get("onboarding_completed"),
                                "next_action": node_update.get("next_action"),
                            },
                        )
                        #endregion
                    final_state = state
                    
                    # 输出友好的信息
                    for node_name, node_update in chunk.items():
                        # 提取消息信息
                        if "messages" in node_update:
                            messages = node_update["messages"]
                            if messages:
                                last_msg = messages[-1]
                                if hasattr(last_msg, "content") and last_msg.content:
                                    info = {
                                        "type": "info",
                                        "node": node_name,
                                        "message": f"Agent 回复: {last_msg.content[:100]}..."
                                    }
                                    yield f"data: {json.dumps(info, ensure_ascii=False)}\n\n"
                                elif hasattr(last_msg, "tool_calls") and last_msg.tool_calls:
                                    tool_names = [tc.get("name", "unknown") for tc in last_msg.tool_calls]
                                    info = {
                                        "type": "info",
                                        "node": node_name,
                                        "message": f"调用工具: {', '.join(tool_names)}"
                                    }
                                    yield f"data: {json.dumps(info, ensure_ascii=False)}\n\n"
            
            # 流式执行完成后，使用累积的最终状态
            if final_state is None:
                # 如果没有累积到状态，使用原始状态
                final_state = state
            
            # 异步维护任务（提纯/归档/压缩）：不阻塞流式返回
            background_tasks.add_task(_run_maintenance_tasks, request.session_id)
            
            # 更新会话
            sessions[request.session_id] = final_state
            
            #region agent log
            _append_debug_log(
                run_id="pre-fix",
                hypothesis_id="H2",
                location="server.py:chat_stream:final_state",
                message="Final state before stream completion",
                data={
                    "has_pending_responses": bool(final_state.get("pending_responses")),
                    "pending_resp_count": len(final_state.get("pending_responses", []) or []),
                    "pending_first_has_card": bool(final_state.get("pending_responses", [{}])[0].get("inquiry_card")) if final_state.get("pending_responses") else False,
                    "state_has_inquiry_card": bool(final_state.get("inquiry_card")),
                    "onboarding_completed": final_state.get("onboarding_completed"),
                    "next_action": final_state.get("next_action"),
                },
            )
            #endregion
            
            # 发送完成信号
            completion = {
                "type": "done",
                "message": "流式执行完成",
                "final_state": {
                    "message_count": len(final_state.get("messages", [])),
                    "has_response": bool(final_state.get("pending_responses")),
                }
            }
            yield f"data: {json.dumps(completion, ensure_ascii=False, default=str)}\n\n"
            
        except Exception as e:
            import traceback
            error_trace = traceback.format_exc()
            print(f"[Stream] Error: {error_trace}")
            
            error_data = {
                "type": "error",
                "error": str(e),
                "traceback": error_trace
            }
            yield f"data: {json.dumps(error_data, ensure_ascii=False)}\n\n"
    
    return StreamingResponse(
        generate_stream(),
        media_type="text/event-stream",
        background=background_tasks,
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no"  # 禁用 nginx 缓冲
        }
    )


# ============ 完成指南接口 ============

@app.post("/api/complete_guide")
async def complete_guide(request: CompleteGuideRequest):
    """
    标记行动指南为已完成并归档
    
    Args:
        request: 包含指南ID、执行状态、反馈和会话ID
    
    Returns:
        更新后的状态
    """
    print(f"✅ 收到完成指南请求: guide_id={request.guide_id}, status={request.execution_status}, session={request.session_id}")
    
    # 获取会话状态
    workflow = get_workflow()
    config = {"configurable": {"thread_id": request.session_id}}
    checkpoint = workflow.get_state(config)
    state = checkpoint.values if checkpoint and checkpoint.values else None
    if not state:
        raise HTTPException(status_code=404, detail="Session not found")
    
    # 查找指南
    action_guides = state.get("action_guides", [])
    guide_index = None
    guide = None
    
    for idx, g in enumerate(action_guides):
        if g.get("id") == request.guide_id:
            guide_index = idx
            guide = g
            break
    
    if not guide:
        raise HTTPException(status_code=404, detail=f"Guide with id {request.guide_id} not found")
    
    if guide.get("status") == "completed":
        # 已经完成，直接返回
        return {"state": state}
    
    # 更新指南状态
    updated_guide = guide.copy()
    updated_guide["status"] = "completed"
    updated_guide["completed_at"] = datetime.now().isoformat()
    updated_guide["execution_status"] = request.execution_status
    updated_guide["user_feedback"] = request.feedback
    
    # 更新 state 中的指南列表
    updated_guides = list(action_guides)
    updated_guides[guide_index] = updated_guide
    state["action_guides"] = updated_guides
    
    # 调用归档函数
    try:
        archive_updates = archive_guide_on_completion(updated_guide, state)
        
        # 合并归档更新到 state
        if "history_archive" in archive_updates:
            state["history_archive"] = archive_updates["history_archive"]
        if "user_context" in archive_updates:
            state["user_context"] = archive_updates["user_context"]
        # v3.1 真源：写回分层 memory（Layer1/2/3）
        if "layer1_memory" in archive_updates:
            state["layer1_memory"] = archive_updates["layer1_memory"]
        if "layer2_memory" in archive_updates:
            state["layer2_memory"] = archive_updates["layer2_memory"]
        if "layer3_memory" in archive_updates:
            state["layer3_memory"] = archive_updates["layer3_memory"]
        
        print(f"✅ 指南归档完成: guide_id={request.guide_id}")
        
    except Exception as e:
        import traceback
        traceback.print_exc()
        print(f"⚠️ 归档失败: {str(e)}")
        # 即使归档失败，也更新状态为已完成
    
    # 持久化到 Checkpointer（若支持）
    if hasattr(workflow, "update_state"):
        workflow.update_state(config, state)
    
    return {
        "success": True,
        "state": state
    }


# ============ 调试接口 ============

@app.get("/api/debug/context/{session_id}")
async def get_debug_context(session_id: str):
    """
    获取当前会话的上下文调试信息
    
    返回分层的上下文状态，用于前端调试面板显示
    """
    workflow = get_workflow()
    config = {"configurable": {"thread_id": session_id}}
    checkpoint = workflow.get_state(config)
    state = checkpoint.values if checkpoint and checkpoint.values else {}
    
    if not state:
        return {
            "error": "Session not found",
            "session_id": session_id,
            "layer1_static": None,
            "layer2_working": None,
            "layer3_conversation": None,
            "layer4_archive": None,
            "crush_chat": None,
        }
    
    # v3.1 真源：分层 memory
    layer1_memory = state.get("layer1_memory") or {}
    layer2_memory = state.get("layer2_memory") or {}
    layer3_memory = state.get("layer3_memory") or {}
    maintenance_queue = state.get("maintenance_queue") or []
    maintenance_flags = state.get("maintenance_flags") or {}

    # 兼容字段（旧）
    user_context = state.get("user_context", {}) or layer1_memory.get("full_data", {})
    history_archive = state.get("history_archive", {})
    
    # 获取 Crush 聊天存储
    crush_chat_storage = state.get("crush_chat_storage", {})
    
    return {
        "session_id": session_id,
        "maintenance": {
            "queue_size": len(maintenance_queue) if isinstance(maintenance_queue, list) else 0,
            "queue": maintenance_queue if isinstance(maintenance_queue, list) else [],
            "flags": maintenance_flags if isinstance(maintenance_flags, dict) else {},
            "last_finalized_at": state.get("maintenance_last_finalized_at"),
        },
        "layered_memory": {
            "layer1": {
                "version": layer1_memory.get("version") if isinstance(layer1_memory, dict) else None,
                "last_updated": layer1_memory.get("last_updated") if isinstance(layer1_memory, dict) else None,
            },
            "layer2": {
                "version": layer2_memory.get("version") if isinstance(layer2_memory, dict) else None,
                "last_updated": layer2_memory.get("last_updated") if isinstance(layer2_memory, dict) else None,
                "status_reports_total": len(layer2_memory.get("all_status_reports", [])) if isinstance(layer2_memory, dict) else 0,
                "action_plans_total": len(layer2_memory.get("all_action_plans", [])) if isinstance(layer2_memory, dict) else 0,
                "action_guides_total": len(layer2_memory.get("all_action_guides", [])) if isinstance(layer2_memory, dict) else 0,
                "dynamic_intels_total": len(layer2_memory.get("dynamic_intels", [])) if isinstance(layer2_memory, dict) else 0,
            },
            "layer3": {
                "version": layer3_memory.get("version") if isinstance(layer3_memory, dict) else None,
                "last_updated": layer3_memory.get("last_updated") if isinstance(layer3_memory, dict) else None,
                "all_messages_count": len(layer3_memory.get("all_messages", [])) if isinstance(layer3_memory, dict) else 0,
                "conversation_summaries_count": len(layer3_memory.get("conversation_summaries", [])) if isinstance(layer3_memory, dict) else 0,
            },
        },
        "layer1_static": {
            "user_info": user_context.get("user_info", {}),
            "crush_info": user_context.get("crush_info", {}),
            "both_info": user_context.get("both_info", {}),
        },
        "layer2_working": {
            "status_report": state.get("status_report"),
            "action_plan": state.get("action_plan"),
            "action_guides": state.get("action_guides", []),
            "recent_messages": state.get("messages", [])[-10:] if state.get("messages") else [],
        },
        "layer3_conversation": {
            "messages_count_workspace": len(state.get("messages", [])),
            "all_messages_count_fullstore": len(layer3_memory.get("all_messages", [])) if isinstance(layer3_memory, dict) else len(state.get("messages", [])),
            "conversation_summaries_count": len(layer3_memory.get("conversation_summaries", [])) if isinstance(layer3_memory, dict) else 0,
            "messages_preview": (layer3_memory.get("all_messages", [])[-5:] if isinstance(layer3_memory, dict) else []) or (state.get("messages", [])[-5:] if state.get("messages") else []),
        },
        "layer4_archive": {
            "status_history_count": len(history_archive.get("status_history", [])),
            "guide_history_count": len(history_archive.get("guide_history", [])),
            "plan_history_count": len(history_archive.get("plan_history", [])),
            "conversation_archive_count": len(history_archive.get("conversation_archive", [])),
            "status_history": history_archive.get("status_history", []),
            "guide_history": history_archive.get("guide_history", []),
        },
        "crush_chat": {
            "metadata": crush_chat_storage.get("metadata", {}) if crush_chat_storage else {},
            "summary": crush_chat_storage.get("summary", {}) if crush_chat_storage else {},
        },
    }


# Mount frontend static files
# We mount this LAST to ensure API routes are checked first
frontend_path = os.path.join(current_dir, "frontend")
if os.path.exists(frontend_path):
    app.mount("/", StaticFiles(directory=frontend_path, html=True), name="static")
else:
    print(f"Warning: Frontend path not found: {frontend_path}")

if __name__ == "__main__":
    print("Starting server on http://0.0.0.0:8000")
    uvicorn.run(app, host="0.0.0.0", port=8000)
