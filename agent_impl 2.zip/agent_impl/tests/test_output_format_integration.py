import pytest

from graph.context_builder import build_context_dict
from graph.state import create_initial_state


NEW_STATUS_REPORT = """## 🧭 情感罗盘

### 当前阶段
你们目前处于暧昧初期...
"""

NEW_ACTION_PLAN = """## 阶段目标
建立稳定的约会关系
"""

NEW_GUIDE_CONTENT = "## 📋 任务卡片：发一条朋友圈"

LEGACY_STATUS_REPORT = {
    "stage": "L2-吸引期",
    "stage_description": "你们处于吸引期",
    "acr_analysis": {"A": "中", "C": "低", "R": "上升"},
    "key_issues": ["需求感过高"],
    "report_content": "## 情感罗盘\n...",
}

LEGACY_ACTION_PLAN = {
    "goal": "建立约会关系",
    "strategy": "循序渐进",
    "phases": [],
    "key_principles": ["保持真诚"],
    "summary": "规划摘要",
}

LEGACY_ACTION_GUIDE = {
    "current_task": "发朋友圈",
    "steps": ["选择照片", "编写文案"],
    "guide_content": "## 任务卡片\n...",
}


class TestOutputFormatIntegration:
    """测试完整流程中的输出格式"""

    def test_status_report_in_context_dict(self):
        state = create_initial_state("测试状态")
        state["status_report"] = NEW_STATUS_REPORT
        ctx = build_context_dict(state, target_agent="status_agent")
        assert isinstance(ctx["status_report"], str)
        assert "情感罗盘" in ctx["status_report"]

    def test_action_plan_in_context_dict(self):
        state = create_initial_state("测试规划")
        state["action_plan"] = NEW_ACTION_PLAN
        ctx = build_context_dict(state, target_agent="plan_agent")
        assert isinstance(ctx["action_plan"], str)
        assert "阶段目标" in ctx["action_plan"]

    def test_action_guides_in_context_dict(self):
        state = create_initial_state("测试指南")
        state["action_guides"] = [
            {"id": "guide_1", "status": "pending", "guide_content": NEW_GUIDE_CONTENT}
        ]
        ctx = build_context_dict(state, target_agent="guide_agent")
        assert isinstance(ctx["action_guides"], str)
        assert "任务卡片" in ctx["action_guides"]

    def test_context_builder_reads_new_format(self):
        state = create_initial_state("全量测试")
        state["status_report"] = NEW_STATUS_REPORT
        state["action_plan"] = NEW_ACTION_PLAN
        state["action_guides"] = [
            {"id": "guide_1", "status": "pending", "guide_content": NEW_GUIDE_CONTENT}
        ]
        ctx = build_context_dict(state, target_agent="main_agent")
        assert "情感罗盘" in ctx["status_report"]
        assert "阶段目标" in ctx["action_plan"]
        assert "任务卡片" in ctx["action_guides"]


class TestLegacyDataCompatibility:
    """测试旧版数据格式的兼容性"""

    def test_legacy_dict_status_report(self):
        state = create_initial_state("旧状态")
        state["status_report"] = LEGACY_STATUS_REPORT
        ctx = build_context_dict(state, target_agent="status_agent")
        assert "情感罗盘" in ctx["status_report"]

    def test_legacy_dict_action_plan(self):
        state = create_initial_state("旧规划")
        state["action_plan"] = LEGACY_ACTION_PLAN
        ctx = build_context_dict(state, target_agent="plan_agent")
        assert "阶段性目标" in ctx["action_plan"] or "核心策略" in ctx["action_plan"]

    def test_legacy_nested_action_guide(self):
        state = create_initial_state("旧指南")
        state["action_guides"] = [
            {"id": "guide_old", "status": "pending", "guide": {"guide_content": "## 旧指南"}}
        ]
        ctx = build_context_dict(state, target_agent="guide_agent")
        assert "旧指南" in ctx["action_guides"]

    def test_mixed_format_handling(self):
        state = create_initial_state("混合格式")
        state["status_report"] = LEGACY_STATUS_REPORT
        state["action_plan"] = NEW_ACTION_PLAN
        state["action_guides"] = [
            {"id": "guide_new", "status": "pending", "guide_content": NEW_GUIDE_CONTENT},
            {"id": "guide_old", "status": "pending", "guide": {"guide_content": "## 旧指南"}},
        ]
        ctx = build_context_dict(state, target_agent="main_agent")
        assert "情感罗盘" in ctx["status_report"]
        assert "阶段目标" in ctx["action_plan"]
        assert "任务卡片" in ctx["action_guides"] and "旧指南" in ctx["action_guides"]


if __name__ == "__main__":
    pytest.main([__file__, "-v"])



