"""
归档管理器 (Archive Manager)
管理分层长期记忆的归档和压缩

职责：
1. Layer 2 归档：报告/规划/指南的历史摘要管理
2. Layer 3 归档：对话压缩和摘要生成
3. Layer 1 更新：从归档内容中提取高价值信息
4. 任务推理归档：任务思考过程 (Rolling Scratchpad) 的滚动摘要

基于 context_strategy.md v3.0 策略文档
"""

from typing import TYPE_CHECKING, Optional
from datetime import datetime
import uuid

if TYPE_CHECKING:
    from graph.state import AgentState

from graph.context_types import (
    # Layer 1
    UserContext,
    Layer1Memory,
    create_empty_user_context,
    create_empty_layer1_memory,
    # Layer 2
    Layer2Memory,
    ActionGuideItem,
    StatusReportItem,
    ActionPlanItem,
    create_empty_layer2_memory,
    DynamicIntelItem,
    get_current_status_report,
    get_active_action_guides,
    # Layer 3
    Layer3Memory,
    ConversationSummary,
    create_empty_layer3_memory,
    create_conversation_summary,
    AgentTaskRegistry,
    TaskState,
    get_active_task,
    # 向后兼容
    HistoryArchive,
    HistorySummary,
    ConversationArchive,
    create_empty_history_archive,
    # 处理状态
    start_layer_processing,
    finish_layer_processing,
    is_layer_processing,
)
from graph.storage_strategy import (
    StorageRouter,
    StorageProcessor,
)
from graph.state import get_message_id
from langchain.messages import RemoveMessage
from graph.nodes.organize_agent import (
    archive_completed_guide,
    archive_replaced_status_report,
    archive_conversation_batch,
    summarize_task_reasoning,
)
from utils.message_utils import count_user_turns


# ============================================================
# 配置常量
# ============================================================

LAYER2_ARCHIVE_CONFIG = {
    "recent_summary_count": 2,      # 最近 N 份保留中等摘要
    "max_one_liner_count": 10,      # 最多保留 N 条一句话摘要
    "max_total_history": 20,        # 每类历史最多保留条数
}

LAYER3_ARCHIVE_CONFIG = {
    "max_recent_turns": 4,          # 保留最近 N 轮完整对话
    "compression_batch_size": 5,    # 每超出 batch_size 轮集中压缩一次
    "compression_threshold": 45,    # 超过此轮次开始检查是否需要压缩（与测试用例对齐）
    "max_summaries": 10,            # 最多保留的对话摘要数
    "reasoning_limit": 10,          # 任务思考过程记录保留条数 (n)
    "reasoning_compression_batch": 2, # 思考过程压缩批量大小 (n-5 到 n 条一起摘要)
}

# 存储策略路由器（供归档流程复用，前置占位便于后续扩展）
_storage_router = StorageRouter()


# ============================================================
# Layer 3: 对话压缩管理
# ============================================================

def check_layer3_compression_needed(state: "AgentState") -> bool:
    """
    检查 Layer 3 是否需要触发对话压缩
    
    触发条件：
    - 对话轮次超过 compression_threshold（25 + 5 = 30）
    - 且超出部分达到 compression_batch_size 的倍数
    
    例如：阈值 30，批量大小 5
    - 29 轮：不压缩
    - 30 轮：不压缩（刚到阈值）
    - 35 轮：触发压缩（超出 5 轮）
    - 36-39 轮：不压缩
    - 40 轮：触发压缩（超出 10 轮）
    """
    # 优先从 layer3_memory 获取消息
    layer3_memory = state.get("layer3_memory")
    if layer3_memory:
        all_messages = layer3_memory.get("all_messages", [])
    else:
        all_messages = state.get("messages", [])
    
    # 以用户消息数量为基准计算"轮次"
    current_turns = count_user_turns(all_messages)
    
    threshold = LAYER3_ARCHIVE_CONFIG["compression_threshold"]
    batch_size = LAYER3_ARCHIVE_CONFIG["compression_batch_size"]
    
    if current_turns <= threshold:
        return False
    
    # 计算超出的轮次
    excess_turns = current_turns - threshold
    
    # 检查是否达到批量压缩的触发点
    return excess_turns > 0 and excess_turns % batch_size == 0


def get_layer3_messages_to_compress(state: "AgentState") -> tuple[list[dict], list[dict]]:
    """
    获取 Layer 3 需要压缩的消息和保留的消息
    
    Returns:
        (to_compress, to_keep): 需要压缩的消息列表, 需要保留的消息列表
    """
    # 优先从 layer3_memory 获取消息
    layer3_memory = state.get("layer3_memory")
    if layer3_memory:
        all_messages = layer3_memory.get("all_messages", [])
    else:
        all_messages = state.get("messages", [])
    
    max_recent = LAYER3_ARCHIVE_CONFIG["max_recent_turns"]
    
    # 以用户消息数量为基准计算轮次
    user_turn_count = count_user_turns(all_messages)
    
    if user_turn_count <= max_recent:
        return [], all_messages
    
    # 找到保留的最近 N 轮用户消息的边界
    # 从后往前数，找到第 max_recent 个用户消息的位置
    user_count = 0
    split_index = len(all_messages)
    for i in range(len(all_messages) - 1, -1, -1):
        from utils.message_utils import get_msg_role_and_content
        role, _ = get_msg_role_and_content(all_messages[i])
        if role == "user":
            user_count += 1
            if user_count == max_recent:
                split_index = i
                break
    
    # 在该用户消息之前的所有消息都压缩
    to_compress = all_messages[:split_index]
    to_keep = all_messages[split_index:]
    
    return to_compress, to_keep


def compress_layer3(state: "AgentState") -> dict:
    """
    执行 Layer 3 对话压缩
    
    流程：
    1. 设置处理状态（标记为正在压缩）
    2. 获取需要压缩的消息
    3. 调用整理 Agent 处理（LLM 生成摘要）
    4. 生成对话摘要，存入 layer3_memory.conversation_summaries
    5. 提取高价值信息，写入 layer1_memory
    6. 清除处理状态
    
    并发处理：
    - 开始压缩前设置 processing_status
    - 保存压缩前的数据快照作为 fallback
    - 压缩完成后清除状态并递增版本号
    
    Returns:
        状态更新字典，包含：
        - layer3_memory: 更新后的 Layer 3 长期记忆
        - layer1_memory: 更新后的 Layer 1 长期记忆（如有新信息）
        - messages: 压缩后保留的消息（向后兼容）
    """
    to_compress, to_keep = get_layer3_messages_to_compress(state)
    
    if not to_compress:
        return {}
    
    # 获取现有的长期记忆
    layer1_memory = state.get("layer1_memory") or create_empty_layer1_memory()
    layer2_memory = state.get("layer2_memory") or create_empty_layer2_memory()
    layer3_memory = state.get("layer3_memory") or create_empty_layer3_memory()
    
    # 检查是否已经在处理中（防止重复触发）
    if is_layer_processing(layer3_memory):
        print("[Archive] Layer 3 is already processing, skipping")
        return {}
    
    # 1. 设置处理状态，保存降级数据快照
    fallback_data = {
        "all_messages": list(layer3_memory.get("all_messages", [])),
        "conversation_summaries": list(layer3_memory.get("conversation_summaries", [])),
        "task_registry": dict(layer3_memory.get("task_registry", {})), # 也保存 task_registry 快照
    }
    layer3_memory = start_layer_processing(
        layer3_memory,
        processing_type="compression",
        fallback_data=fallback_data,
    )
    
    print(f"[Archive] Layer 3 compression started, processing {len(to_compress)} messages")
    
    # 获取 Layer 1 的用户上下文
    existing_context = layer1_memory.get("full_data", create_empty_user_context())
    
    try:
        # 2. 调用整理 Agent 处理对话归档（这里会调用 LLM）
        result = archive_conversation_batch(to_compress, existing_context)
        
        # 3. 创建对话摘要
        conv_archive = result.get("conversation_archive", {})
        new_summary = create_conversation_summary(
            summary=conv_archive.get("summary", ""),
            turn_count=conv_archive.get("turn_count", len(to_compress)),
            key_topics=conv_archive.get("key_topics", []),
            extracted_info=conv_archive.get("extracted_info", {}),
        )
        
        # 4. 通过存储策略路由到 Layer 3 并写入摘要
        decision = _storage_router.route({"type": "conversation_summary", "payload": conv_archive})
        max_summaries = LAYER3_ARCHIVE_CONFIG["max_summaries"]
        if decision.get("target_layer") != "layer3":
            print("[Archive] StorageRouter returned non-layer3 target, fallback to layer3")
        updated_layer3 = StorageProcessor.append_conversation_summary(
            layer3_memory,
            new_summary,
            max_summaries=max_summaries,
            total_turns_delta=len(to_compress),
        )
        
        # 更新 Layer 1 长期记忆（如有提取的信息）
        updated_context = result.get("updated_context", existing_context)
        updated_layer1 = StorageProcessor.save_layer1(
            updated_context,
            layer1_memory,
        )

        # 5. 写入动态情报
        updated_layer2 = layer2_memory
        for intel in result.get("dynamic_intels", []):
            updated_layer2 = StorageProcessor.upsert_dynamic_intel(
                updated_layer2,
                intel,
            )
        
        print(f"[Archive] Layer 3 compressed: {len(to_compress)} messages -> summary, kept {len(to_keep)} messages")
        
    except Exception as e:
        # 压缩失败，清除处理状态但不更新数据
        print(f"[Archive] Layer 3 compression failed: {e}")
        layer3_memory = finish_layer_processing(layer3_memory, increment_version=False)
        return {
            "layer3_memory": layer3_memory,
        }
    
    # 使用 RemoveMessage 删除工作区中的旧消息（全量存储已保留）
    remove_ops = []
    for m in to_compress:
        mid = get_message_id(m)
        if mid:
            remove_ops.append(RemoveMessage(id=mid))
    
    messages_update = remove_ops if remove_ops else []
    
    return {
        "layer3_memory": updated_layer3,
        "layer1_memory": updated_layer1,
        "layer2_memory": updated_layer2,
        "messages": messages_update,  # 仅删除工作区消息
        "user_context": updated_context,  # 向后兼容
    }


# ============================================================
# Layer 3: 任务思考过程 (Reasoning) 压缩管理
# ============================================================

def check_task_reasoning_compression_needed(state: "AgentState") -> list[tuple[str, str]]:
    """
    检查 Layer 3 中的任务思考过程是否需要压缩
    
    触发条件：
    - 任意活跃任务的 reasoning 列表长度超过 reasoning_limit (n)
    
    Returns:
        需要压缩的任务列表 [(agent_name, task_id), ...]
    """
    layer3_memory = state.get("layer3_memory")
    if not layer3_memory:
        return []
        
    task_registry = layer3_memory.get("task_registry", {})
    limit = LAYER3_ARCHIVE_CONFIG["reasoning_limit"]
    
    tasks_to_compress = []
    
    for agent_name, tasks in task_registry.items():
        if not tasks:
            continue
            
        active_task = get_active_task(tasks)
        if active_task and len(active_task.get("reasoning", [])) > limit:
            tasks_to_compress.append((agent_name, active_task.get("task_id")))
            
    return tasks_to_compress


def compress_task_reasoning(state: "AgentState") -> dict:
    """
    执行任务思考过程压缩
    
    逻辑：
    1. 找到需要压缩的任务
    2. 取出 0 到 n-5 条 reasoning 记录
    3. 调用 LLM 生成摘要
    4. 将摘要追加/更新到 summary 字段
    5. 更新 reasoning 列表，只保留最近 n-5 条
    
    Returns:
        状态更新字典 (layer3_memory)
    """
    tasks_to_compress = check_task_reasoning_compression_needed(state)
    if not tasks_to_compress:
        return {}
        
    layer3_memory = state.get("layer3_memory") or create_empty_layer3_memory()
    
    # 检查是否已经在处理中
    if is_layer_processing(layer3_memory):
        print("[Archive] Layer 3 is processing, skipping reasoning compression")
        return {}
        
    # 设置处理状态
    fallback_data = {
        "all_messages": list(layer3_memory.get("all_messages", [])),
        "conversation_summaries": list(layer3_memory.get("conversation_summaries", [])),
        "task_registry": dict(layer3_memory.get("task_registry", {})),
    }
    layer3_memory = start_layer_processing(
        layer3_memory,
        processing_type="compression",
        fallback_data=fallback_data,
    )
    
    task_registry = layer3_memory.get("task_registry", {})
    # 深度复制 task_registry 以便修改
    updated_registry = {k: [t.copy() for t in v] for k, v in task_registry.items()}
    
    limit = LAYER3_ARCHIVE_CONFIG["reasoning_limit"]
    batch_size = LAYER3_ARCHIVE_CONFIG["reasoning_compression_batch"]
    # 保留最近 batch_size 条，压缩之前的
    keep_count = batch_size 
    
    try:
        for agent_name, task_id in tasks_to_compress:
            tasks = updated_registry.get(agent_name, [])
            target_task = None
            task_idx = -1
            
            for i, t in enumerate(tasks):
                if t.get("task_id") == task_id:
                    target_task = t
                    task_idx = i
                    break
            
            if not target_task:
                continue
                
            reasoning = target_task.get("reasoning", [])
            # 需要压缩的部分：从开头到 (总数 - 保留数)
            split_idx = len(reasoning) - keep_count
            to_compress_items = reasoning[:split_idx]
            to_keep_items = reasoning[split_idx:]
            
            # 调用 LLM 生成摘要
            current_summary = target_task.get("summary", "")
            new_summary = summarize_task_reasoning(to_compress_items, current_summary)
            
            # 更新任务状态
            target_task["summary"] = new_summary
            target_task["reasoning"] = to_keep_items
            updated_registry[agent_name][task_idx] = target_task
            
            print(f"[Archive] Compressed task reasoning for {task_id}: {len(to_compress_items)} items -> summary")

        # 更新 Layer 3
        updated_layer3 = Layer3Memory(
            all_messages=layer3_memory.get("all_messages", []),
            conversation_summaries=layer3_memory.get("conversation_summaries", []),
            task_registry=updated_registry,
            extraction_config=layer3_memory.get("extraction_config", {}),
            processing_status=None,
            last_updated=datetime.now().isoformat(),
            total_turns=layer3_memory.get("total_turns", 0),
            version=layer3_memory.get("version", 1) + 1,
        )
        
        return {"layer3_memory": updated_layer3}
        
    except Exception as e:
        print(f"[Archive] Task reasoning compression failed: {e}")
        layer3_memory = finish_layer_processing(layer3_memory, increment_version=False)
        return {"layer3_memory": layer3_memory}


# ============================================================
# Layer 2: 报告/指南归档管理
# ============================================================

def archive_guide_to_layer2(
    guide: ActionGuideItem,
    state: "AgentState",
) -> dict:
    """
    当行动指南完成时，归档到 Layer 2 长期记忆
    
    Args:
        guide: 已完成的行动指南
        state: 当前状态
    
    Returns:
        状态更新字典
    """
    # 获取现有的长期记忆
    layer1_memory = state.get("layer1_memory") or create_empty_layer1_memory()
    layer2_memory = state.get("layer2_memory") or create_empty_layer2_memory()
    
    existing_context = layer1_memory.get("full_data", create_empty_user_context())
    
    # 调用整理 Agent
    result = archive_completed_guide(guide, existing_context)
    
    # 更新指南的摘要字段
    guide_summary = result.get("guide_summary", {})
    guide["summary"] = guide_summary.get("summary", "")
    guide["one_liner"] = guide_summary.get("one_liner", "")
    guide["status"] = "completed"
    guide["completed_at"] = datetime.now().isoformat()
    
    # 更新 Layer 2 长期记忆中的指南列表
    decision = _storage_router.route({"type": "action_guide", "payload": guide})
    if decision.get("target_layer") != "layer2":
        print("[Archive] StorageRouter returned non-layer2 target, fallback to layer2")
    updated_layer2 = StorageProcessor.upsert_completed_guide(
        layer2_memory,
        guide,
        recent_count=LAYER2_ARCHIVE_CONFIG["recent_summary_count"],
        max_one_liner=LAYER2_ARCHIVE_CONFIG["max_one_liner_count"],
    )
    
    # 更新 Layer 1（如有提取的信息）
    updated_context = result.get("updated_context", existing_context)
    updated_layer1 = Layer1Memory(
        full_data=updated_context,
        extraction_config=layer1_memory.get("extraction_config", {}),
        last_updated=datetime.now().isoformat(),
        update_count=layer1_memory.get("update_count", 0) + 1,
    )
    
    return {
        "layer2_memory": updated_layer2,
        "layer1_memory": updated_layer1,
        "user_context": updated_context,  # 向后兼容
    }


def archive_status_to_layer2(
    old_report: StatusReportItem,
    state: "AgentState",
) -> dict:
    """
    当现状分析被新版替换时，归档到 Layer 2 长期记忆
    
    Args:
        old_report: 被替换的旧报告
        state: 当前状态
    
    Returns:
        状态更新字典
    """
    # 获取现有的长期记忆
    layer1_memory = state.get("layer1_memory") or create_empty_layer1_memory()
    layer2_memory = state.get("layer2_memory") or create_empty_layer2_memory()
    
    existing_context = layer1_memory.get("full_data", create_empty_user_context())
    
    # 调用整理 Agent
    result = archive_replaced_status_report(old_report, existing_context)
    
    # 更新报告的摘要字段
    status_summary = result.get("status_summary", {})
    old_report["summary"] = status_summary.get("summary", "")
    old_report["one_liner"] = status_summary.get("one_liner", "")
    old_report["is_current"] = False
    
    # 更新 Layer 2 长期记忆中的报告列表
    decision = _storage_router.route({"type": "status_report", "payload": old_report})
    if decision.get("target_layer") != "layer2":
        print("[Archive] StorageRouter returned non-layer2 target, fallback to layer2")
    updated_layer2 = StorageProcessor.upsert_status_report(
        layer2_memory,
        old_report,
        recent_count=LAYER2_ARCHIVE_CONFIG["recent_summary_count"],
        max_one_liner=LAYER2_ARCHIVE_CONFIG["max_one_liner_count"],
    )
    
    # 更新 Layer 1（如有提取的信息）
    updated_context = result.get("updated_context", existing_context)
    updated_layer1 = Layer1Memory(
        full_data=updated_context,
        extraction_config=layer1_memory.get("extraction_config", {}),
        last_updated=datetime.now().isoformat(),
        update_count=layer1_memory.get("update_count", 0) + 1,
    )

    # 写入动态情报
    updated_layer2 = updated_layer2
    for intel in result.get("dynamic_intels", []):
        updated_layer2 = StorageProcessor.upsert_dynamic_intel(
            updated_layer2,
            intel,
        )
    
    return {
        "layer2_memory": updated_layer2,
        "layer1_memory": updated_layer1,
        "user_context": updated_context,  # 向后兼容
    }


# ============================================================
# 向后兼容：旧版归档函数
# ============================================================

def check_conversation_compression_needed(state: "AgentState") -> bool:
    """
    检查是否需要触发对话压缩（向后兼容）
    
    @deprecated: 请使用 check_layer3_compression_needed
    """
    return check_layer3_compression_needed(state)


def compress_conversation(state: "AgentState") -> dict:
    """
    执行对话压缩（向后兼容）
    
    @deprecated: 请使用 compress_layer3
    """
    result = compress_layer3(state)
    
    # 同时更新旧版 history_archive
    if result:
        existing_archive = state.get("history_archive") or create_empty_history_archive()
        
        # 从 layer3_memory 获取新的摘要
        layer3_memory = result.get("layer3_memory", {})
        new_summaries = layer3_memory.get("conversation_summaries", [])
        
        if new_summaries:
            # 转换为旧版格式
            conv_archives = []
            for summary in new_summaries:
                conv_archive = ConversationArchive(
                    id=summary.get("id", ""),
                    summary=summary.get("summary", ""),
                    start_time=summary.get("start_time", ""),
                    end_time=summary.get("end_time", ""),
                    turn_count=summary.get("turn_count", 0),
                    key_topics=summary.get("key_topics", []),
                    extracted_info=summary.get("extracted_info", {}),
                )
                conv_archives.append(conv_archive)
            
            updated_archive = HistoryArchive(
                status_history=existing_archive.get("status_history", []),
                plan_history=existing_archive.get("plan_history", []),
                guide_history=existing_archive.get("guide_history", []),
                conversation_archive=conv_archives,
            )
            result["history_archive"] = updated_archive
    
    return result


def archive_guide_on_completion(
    guide: ActionGuideItem,
    state: "AgentState",
) -> dict:
    """
    当行动指南完成时触发归档（向后兼容）
    
    @deprecated: 请使用 archive_guide_to_layer2
    """
    result = archive_guide_to_layer2(guide, state)
    
    # 同时更新旧版 history_archive
    existing_archive = state.get("history_archive") or create_empty_history_archive()
    
    guide_summary = HistorySummary(
        id=guide.get("id", ""),
        summary=guide.get("summary", ""),
        one_liner=guide.get("one_liner", ""),
        created_at=guide.get("created_at", ""),
        full_content=guide.get("guide", {}).get("guide_content", ""),
    )
    
    updated_archive = add_to_history(existing_archive, guide_summary, "guide_history")
    result["history_archive"] = updated_archive
    
    return result


def archive_status_on_replacement(
    old_report: dict,
    state: "AgentState",
) -> dict:
    """
    当现状分析被新版替换时触发归档（向后兼容）
    
    @deprecated: 请使用 archive_status_to_layer2
    """
    # 转换为新版格式
    report_item = StatusReportItem(
        id=old_report.get("id", str(uuid.uuid4())[:8]),
        report_id=old_report.get("report_id", 0),
        is_current=False,
        stage=old_report.get("stage", ""),
        stage_description=old_report.get("stage_description", ""),
        acr_analysis=old_report.get("acr_analysis", {}),
        key_issues=old_report.get("key_issues", []),
        risk_points=old_report.get("risk_points", []),
        report_content=old_report.get("report_content", ""),
        created_at=old_report.get("created_at", datetime.now().isoformat()),
    )
    
    result = archive_status_to_layer2(report_item, state)
    
    # 同时更新旧版 history_archive
    existing_archive = state.get("history_archive") or create_empty_history_archive()
    
    status_summary = HistorySummary(
        id=report_item.get("id", ""),
        summary=report_item.get("summary", ""),
        one_liner=report_item.get("one_liner", ""),
        created_at=report_item.get("created_at", ""),
        full_content=report_item.get("report_content", ""),
    )
    
    updated_archive = add_to_history(existing_archive, status_summary, "status_history")
    result["history_archive"] = updated_archive
    
    return result


def add_to_history(
    existing_archive: HistoryArchive,
    new_summary: HistorySummary,
    history_type: str,
) -> HistoryArchive:
    """
    添加新摘要到历史归档（向后兼容）
    """
    archive_dict = {
        "status_history": list(existing_archive.get("status_history", [])),
        "plan_history": list(existing_archive.get("plan_history", [])),
        "guide_history": list(existing_archive.get("guide_history", [])),
        "conversation_archive": list(existing_archive.get("conversation_archive", [])),
    }
    
    if history_type in archive_dict:
        archive_dict[history_type].insert(0, new_summary)
        archive_dict[history_type] = downgrade_old_summaries(archive_dict[history_type])
    
    return HistoryArchive(**archive_dict)


def downgrade_old_summaries(history_list: list[HistorySummary]) -> list[HistorySummary]:
    """
    降级旧的历史摘要（向后兼容）
    """
    recent_count = LAYER2_ARCHIVE_CONFIG["recent_summary_count"]
    max_one_liner = LAYER2_ARCHIVE_CONFIG["max_one_liner_count"]
    max_total = recent_count + max_one_liner
    
    processed = []
    for i, item in enumerate(history_list[:max_total]):
        if i < recent_count:
            processed.append(item)
        else:
            downgraded = HistorySummary(
                id=item.get("id", ""),
                summary="",
                one_liner=item.get("one_liner", item.get("summary", "")[:30]),
                created_at=item.get("created_at", ""),
                full_content=item.get("full_content", ""),
            )
            processed.append(downgraded)
    
    return processed


# ============================================================
# 统一归档入口
# ============================================================

def process_archiving_if_needed(state: "AgentState") -> dict:
    """
    统一归档入口：检查并处理所有需要归档的内容
    
    在每轮结束时调用，检查：
    1. Layer 3 是否需要对话压缩
    2. Layer 3 是否需要任务思考过程压缩
    3. Layer 2 是否有已完成的行动指南需要归档 (在 main_agent 中已触发，这里略)
    
    Returns:
        状态更新字典（如果没有需要归档的内容，返回空字典）
    """
    updates = {}
    
    # 1. 检查 Layer 3 对话压缩
    if check_layer3_compression_needed(state):
        compression_result = compress_layer3(state)
        updates.update(compression_result)
        
    # 2. 检查任务思考过程压缩
    if check_task_reasoning_compression_needed(state):
        reasoning_result = compress_task_reasoning(state)
        # 合并更新 (小心覆盖)
        if "layer3_memory" in updates and "layer3_memory" in reasoning_result:
            # 如果两者都更新了 layer3，需要小心合并
            # 简单起见，这里假设两者不会冲突太严重，或者我们接受后者的覆盖
            # 更好的做法是在 memory 对象内部做合并，或者串行处理并传递更新后的 state
            pass # TODO: 处理合并冲突，暂且认为概率较低
        updates.update(reasoning_result)
    
    return updates


def refine_on_onboarding_complete(state: "AgentState") -> dict:
    """
    Onboarding 结束时触发的提纯：
    - 读取全量对话
    - 提取静态情报 & 动态情报
    - 生成对话摘要（可选）
    """
    layer1_memory = state.get("layer1_memory") or create_empty_layer1_memory()
    layer2_memory = state.get("layer2_memory") or create_empty_layer2_memory()
    layer3_memory = state.get("layer3_memory") or create_empty_layer3_memory()

    messages = layer3_memory.get("all_messages", state.get("messages", []))
    if not messages:
        return {}

    existing_context = layer1_memory.get("full_data", create_empty_user_context())
    result = archive_conversation_batch(messages, existing_context)

    updated_context = result.get("updated_context", existing_context)
    updated_layer1 = StorageProcessor.save_layer1(updated_context, layer1_memory)

    updated_layer2 = layer2_memory
    for intel in result.get("dynamic_intels", []):
        updated_layer2 = StorageProcessor.upsert_dynamic_intel(updated_layer2, intel)

    updated_layer3 = layer3_memory
    conv_archive = result.get("conversation_archive")
    if conv_archive:
        new_summary = create_conversation_summary(
            summary=conv_archive.get("summary", ""),
            turn_count=conv_archive.get("turn_count", len(messages)),
            key_topics=conv_archive.get("key_topics", []),
            extracted_info=conv_archive.get("extracted_info", {}),
        )
        max_summaries = LAYER3_ARCHIVE_CONFIG["max_summaries"]
        updated_layer3 = StorageProcessor.append_conversation_summary(
            layer3_memory,
            new_summary,
            max_summaries=max_summaries,
            total_turns_delta=conv_archive.get("turn_count", len(messages)),
        )

    return {
        "layer1_memory": updated_layer1,
        "layer2_memory": updated_layer2,
        "layer3_memory": updated_layer3,
        "user_context": updated_context,
    }


# ============================================================
# 调试/查询函数
# ============================================================

def get_archive_stats(state: "AgentState") -> dict:
    """
    获取归档统计信息（用于调试）
    """
    layer2_memory = state.get("layer2_memory", {})
    layer3_memory = state.get("layer3_memory", {})
    
    all_messages = layer3_memory.get("all_messages", state.get("messages", []))
    all_guides = layer2_memory.get("all_action_guides", [])
    all_reports = layer2_memory.get("all_status_reports", [])
    
    return {
        "conversation_turns": len(all_messages),
        "conversation_summaries": len(layer3_memory.get("conversation_summaries", [])),
        "status_reports_total": len(all_reports),
        "status_reports_history": len([r for r in all_reports if not r.get("is_current")]),
        "action_guides_total": len(all_guides),
        "action_guides_completed": len([g for g in all_guides if g.get("status") == "completed"]),
        "compression_needed": check_layer3_compression_needed(state),
    }


def get_full_history_content(
    state: "AgentState",
    layer: str,
    item_type: str,
    index: int,
) -> Optional[str]:
    """
    获取历史记录的完整内容（抽屉式调用）
    
    Args:
        state: 当前状态
        layer: "layer2" 或 "layer3"
        item_type: "status_report" / "action_guide" / "conversation"
        index: 历史记录索引
    
    Returns:
        完整内容，如果不存在返回 None
    """
    if layer == "layer2":
        layer2_memory = state.get("layer2_memory", {})
        
        if item_type == "status_report":
            reports = layer2_memory.get("all_status_reports", [])
            history = [r for r in reports if not r.get("is_current")]
            if 0 <= index < len(history):
                return history[index].get("report_content")
        
        elif item_type == "action_guide":
            guides = layer2_memory.get("all_action_guides", [])
            completed = [g for g in guides if g.get("status") == "completed"]
            if 0 <= index < len(completed):
                return completed[index].get("guide", {}).get("guide_content")
    
    elif layer == "layer3":
        layer3_memory = state.get("layer3_memory", {})
        
        if item_type == "conversation":
            summaries = layer3_memory.get("conversation_summaries", [])
            if 0 <= index < len(summaries):
                return summaries[index].get("summary")
    
    # 向后兼容：尝试从旧版 history_archive 获取
    archive = state.get("history_archive", {})
    type_map = {
        "status_report": "status_history",
        "action_guide": "guide_history",
        "conversation": "conversation_archive",
    }
    
    history_key = type_map.get(item_type)
    if history_key:
        history_list = archive.get(history_key, [])
        if 0 <= index < len(history_list):
            return history_list[index].get("full_content", history_list[index].get("summary"))
    
    return None
