"""
Onboarding Agent

职责：
- 首次使用时补齐用户/Crush 基础画像与核心痛点
- 每轮单问，最多 onboarding_max_turns 轮
- 信息充足时输出 onboarding_handoff，给主 Agent 提示下一步
"""

import json
import time
from pathlib import Path
from typing import Any, Dict

from langgraph.types import Command

from config import get_llm
from onboarding.state import OnboardingHandoff
from utils.prompt_loader import parse_frontmatter


PROMPT_PATH = Path(__file__).parent / "prompts" / "onboarding_agent.md"
LOGIC_PATH = Path(__file__).parent / "onboarding_logic.md"
LOG_PATH = Path("/Users/ant/Desktop/Crushe/模型策略/.cursor/debug.log")


#region agent log
def _append_debug_log(run_id: str, hypothesis_id: str, location: str, message: str, data: dict):
    """Append a single NDJSON debug log line to the shared log path."""
    payload = {
        "sessionId": "debug-session",
        "runId": run_id,
        "hypothesisId": hypothesis_id,
        "location": location,
        "message": message,
        "data": data,
        "timestamp": int(time.time() * 1000),
    }
    try:
        with LOG_PATH.open("a", encoding="utf-8") as f:
            f.write(json.dumps(payload, ensure_ascii=False) + "\n")
    except Exception:
        # Logging failure should never break execution
        pass
#endregion


def _load_reference_questions() -> str:
    try:
        return LOGIC_PATH.read_text(encoding="utf-8").strip()
    except FileNotFoundError:
        return ""


def _load_prompt(reference_questions: str) -> str:
    """
    加载 Prompt，并用占位符注入参考问题。
    如果未找到占位符，则降级为在结尾追加参考问题。
    """
    raw = PROMPT_PATH.read_text(encoding="utf-8")
    _, content = parse_frontmatter(raw)
    content = content.strip()

    placeholder = "{REFERENCE_QUESTIONS}"
    if placeholder in content:
        return content.replace(placeholder, reference_questions or "（暂无参考问题）")

    # fallback：无占位符则直接拼接
    suffix = "\n\n## 参考问题（可自由改写）\n" + (reference_questions or "（暂无参考问题）")
    return content + suffix


def _safe_json_loads(text: str) -> Dict[str, Any]:
    """宽松解析 LLM 输出为 JSON。失败则返回空字典。"""
    if not text:
        return {}
    try:
        if "```json" in text:
            text = text.split("```json")[1].split("```")[0]
        elif "```" in text:
            text = text.split("```")[1].split("```")[0]
        start = text.find("{")
        end = text.rfind("}") + 1
        if start != -1 and end > start:
            text = text[start:end]
        return json.loads(text)
    except Exception:
        return {}


def _pick_next_question(collected: dict) -> str:
    """基于缺口挑选下一问（简单规则，LLM 失败时的兜底）。"""
    user_profile = collected.get("user_profile", {})
    crush_profile = collected.get("crush_profile", {})
    pain_points = collected.get("pain_points", [])

    if not user_profile.get("gender"):
        return "你的性别是？"
    if not user_profile.get("birth_year"):
        return "你的出生年份是？"
    if not user_profile.get("experience_level"):
        return "你觉得自己的情感经验阶段是？（萌新/进阶/资深/疗愈期）"
    if not crush_profile.get("name"):
        return "方便告诉我对方的昵称或备注吗？"
    if not crush_profile.get("gender"):
        return "Ta 的性别是？"
    if not crush_profile.get("age"):
        return "Ta 的年龄或预估年龄是？"
    if not crush_profile.get("channel"):
        return "你们是如何认识的？（社交软件/偶遇/朋友介绍/同事同学等）"
    if not pain_points:
        return "现在最让你头疼的点是什么？比如找不到话题、约不出来、忽冷忽热等。"
    return ""


def _merge_collected(collected: dict, new_raw: str) -> dict:
    """轻量合并收集信息：目前仅追加用户自由文本，留待后续模型抽取。"""
    merged = dict(collected or {})
    history = list(merged.get("raw_inputs", []))
    if new_raw:
        history.append(new_raw.strip())
    merged["raw_inputs"] = history
    merged.setdefault("user_profile", {})
    merged.setdefault("crush_profile", {})
    merged.setdefault("pain_points", [])
    return merged


from graph.state import convert_message_to_dict


def _convert_messages_to_dict(messages: list) -> list:
    """
    将 LangChain Message 或 dict 统一转为 dict，避免测试中对 .get 的访问报错。
    """
    result = []
    for m in messages or []:
        try:
            msg = convert_message_to_dict(m)
            role = msg.get("role")
            if role == "human":
                msg["role"] = "user"
            elif role == "ai":
                msg["role"] = "assistant"
            result.append(msg)
        except Exception:
            # 最小容错
            if isinstance(m, dict):
                role = m.get("role")
                if role == "human":
                    m["role"] = "user"
                elif role == "ai":
                    m["role"] = "assistant"
                result.append(m)
            elif hasattr(m, "content"):
                role = getattr(m, "type", getattr(m, "role", "assistant"))
                if role == "human":
                    role = "user"
                elif role == "ai":
                    role = "assistant"
                result.append({"role": role, "content": m.content})
    return result


def _build_conversation_history(messages: list) -> str:
    """
    构建对话历史（与主 Agent 格式一致）
    
    格式: **用户**: xxx / **小话**: xxx
    """
    if not messages:
        return "无历史对话"
    
    formatted = []
    for msg in messages:
        role = msg.get("role", "")
        content = msg.get("content", "")
        
        if not content or not content.strip():
            continue
        
        # 处理 assistant 消息：如果是 JSON，提取 response 字段
        if role == "assistant":
            content = _extract_response_from_json(content)
            if not content:
                continue
            formatted.append(f"**小话**: {content}")
        elif role == "user":
            formatted.append(f"**用户**: {content}")
    
    if not formatted:
        return "无历史对话"
    
    return "\n\n".join(formatted)


def _extract_response_from_json(content: str) -> str:
    """
    从 JSON 格式的 assistant 消息中提取 response 字段
    """
    if not content:
        return ""
    
    content = content.strip()
    
    # 尝试解析 JSON
    try:
        if "```json" in content:
            json_str = content.split("```json")[1].split("```")[0].strip()
        elif "```" in content:
            json_str = content.split("```")[1].split("```")[0].strip()
        elif content.startswith("{"):
            start = content.find("{")
            end = content.rfind("}") + 1
            json_str = content[start:end]
        else:
            return content
        
        data = json.loads(json_str)
        
        parts = []
        
        # 提取 response
        response = data.get("response", "")
        if response:
            parts.append(response)
        
        # 如果有 inquiry_card，提取问题文本
        inquiry_card = data.get("inquiry_card")
        if inquiry_card and inquiry_card.get("questions"):
            questions = inquiry_card.get("questions", [])
            if questions:
                question_texts = []
                for q in questions:
                    if isinstance(q, dict):
                        q_text = q.get("question", "")
                        if q_text:
                            question_texts.append(f"- {q_text}")
                    elif isinstance(q, str):
                        question_texts.append(f"- {q}")
                
                if question_texts:
                    parts.append("【提问】\n" + "\n".join(question_texts))
        
        if parts:
            return "\n".join(parts)
        
        return content
        
    except (json.JSONDecodeError, KeyError, IndexError):
        return content


def onboarding_agent_node(state: dict) -> dict:
    """
    Onboarding 节点：
    - 调用 LLM 生成下一问或直接输出 handoff
    - 对话历史格式与主 Agent 保持一致
    """
    reference = _load_reference_questions()
    llm = get_llm(temperature=0.3)
    prompt_body = _load_prompt(reference)

    user_message = state.get("user_message", "")
    collected_info = state.get("collected_info", {}) or {}
    turn_count = state.get("onboarding_turn_count", 0)
    max_turns = state.get("onboarding_max_turns", 3)
    last_question = state.get("last_onboarding_question")

    # 统一消息为 dict，确保不丢失已有用户消息
    existing_messages = _convert_messages_to_dict(state.get("messages", []))

    # 构建对话历史（与主 Agent 格式一致）
    conversation_history = _build_conversation_history(existing_messages)

    # 组装给 LLM 的上下文（使用占位符替换）
    prompt = prompt_body.format(
        conversation_history=conversation_history,
        turn_count=turn_count,
        max_turns=max_turns,
    )

    llm_resp = llm.invoke(prompt)
    parsed = _safe_json_loads(getattr(llm_resp, "content", ""))

    needs_more = bool(parsed.get("needs_more", False))
    # 优先使用 inquiry_card 中的问题，兼容旧格式 question
    inquiry_card = parsed.get("inquiry_card") or {}
    questions = inquiry_card.get("questions", [])
    question_text = questions[0].get("question") if questions else parsed.get("question")

    #region agent log
    _append_debug_log(
        run_id="pre-fix",
        hypothesis_id="H1",
        location="onboarding_agent.py:onboarding_agent_node:parsed",
        message="Parsed onboarding LLM output",
        data={
            "needs_more": needs_more,
            "has_inquiry_card": bool(inquiry_card),
            "questions_count": len(questions),
            "question_text": question_text,
            "turn_count": turn_count,
            "max_turns": max_turns,
        },
    )
    #endregion

    # 如果 LLM 没生成有效问题，尝试兜底
    if not question_text:
        question_text = _pick_next_question(collected_info)

    # 构造 response/intro
    response_text = parsed.get("response") or inquiry_card.get("intro") or (question_text or "为确保理解你的情况，我想确认一下关键背景。")
    
    # 构造完整的 inquiry_card（如果缺失）
    if needs_more and not questions and question_text:
        inquiry_card = {
            "questions": [{
                "id": f"onboard_q_{turn_count}",
                "question": question_text,
                "type": "free_input_question",
                "info_type": 1,
                "is_required": True,
                "purpose": "补充关键背景"
            }],
            "intro": response_text,
            "reasoning": "Based on missing profile info"
        }

    recommendation = parsed.get("recommendation", "")
    suggested_action = parsed.get("suggested_action", "end_turn")
    reason = parsed.get("reason", "")
    updated_info = parsed.get("collected_info") or collected_info

    # 如果模型未给出问题且仍需追问，直接结束
    if needs_more and not question_text:
        needs_more = False

    # 追加当前输入到收集信息
    updated_info = _merge_collected(updated_info, user_message)

    if needs_more and turn_count < max_turns:
        # 不使用 interrupt，直接返回提问卡和回复，结束本轮
        result = {
            "onboarding_completed": False,
            "onboarding_turn_count": turn_count + 1,
            "last_onboarding_question": question_text,
            "collected_info": updated_info,
            "inquiry_card": inquiry_card,  # 顶层暴露给前端
            "pending_responses": [
                {
                    "from": "onboarding",
                    "content": response_text,
                    "phase": "immediate",
                    "inquiry_card": inquiry_card,
                }
            ],
            "messages": existing_messages + [
                {"role": "assistant", "content": llm_resp.content},  # 保存原始输出以便后续提取
            ],
            "pending_questions": [question_text] if question_text else [],
            "route_to": "end",  # 结束本轮，等待用户回答
            "next_action": "ask_user",
        }
        #region agent log
        _append_debug_log(
            run_id="pre-fix",
            hypothesis_id="H1",
            location="onboarding_agent.py:onboarding_agent_node:return_needs_more",
            message="Returning onboarding inquiry card",
            data={
                "questions_count": len(inquiry_card.get("questions", [])) if inquiry_card else 0,
                "pending_has_card": bool(result["pending_responses"][0].get("inquiry_card")),
                "result_inquiry_card_present": bool(result.get("inquiry_card")),
                "pending_from": result["pending_responses"][0].get("from"),
                "turn_count": result["onboarding_turn_count"],
            },
        )
        #endregion
        return result

    # 信息足够或达到上限，生成 handoff
    handoff: OnboardingHandoff = {
        "collected_context": updated_info,
        "recommendation": recommendation or "信息已收集完毕，进入主流程进一步分析。",
        "suggested_action": suggested_action if suggested_action in {"call_status", "call_plan", "call_guide", "end_turn", "consult_only"} else "call_status",
        "reason": reason or "Onboarding 收集完成。",
    }

    result = {
        "onboarding_completed": True,
        "onboarding_handoff": handoff,
        "collected_info": updated_info,
        "pending_responses": [
            {
                "from": "onboarding",
                "content": handoff["recommendation"],
                "phase": "immediate",
            }
        ],
        "messages": existing_messages + [{"role": "assistant", "content": llm_resp.content}],
    }
    #region agent log
    _append_debug_log(
        run_id="pre-fix",
        hypothesis_id="H2",
        location="onboarding_agent.py:onboarding_agent_node:return_completed",
        message="Onboarding completed path",
        data={
            "handoff_suggested_action": handoff.get("suggested_action"),
            "has_pending": bool(result.get("pending_responses")),
            "collected_info_keys": list(updated_info.keys()),
        },
    )
    #endregion
    return result
